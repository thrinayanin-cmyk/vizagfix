import React, { useState } from 'react';
import { UserProfile, Complaint } from '../types';
import {
  User,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Edit3,
  Check,
  Shield,
  FileText,
  Clock,
  Sparkles,
} from 'lucide-react';

interface UserProfileViewProps {
  user: UserProfile;
  complaints: Complaint[];
  onUpdateUser: (updated: UserProfile) => void;
  onFileComplaintClick: () => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({
  user,
  complaints,
  onUpdateUser,
  onFileComplaintClick,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [name, setName] = useState(user.name);
  const [phone, setPhone] = useState(user.phone);
  const [address, setAddress] = useState(user.address);
  const [pincode, setPincode] = useState(user.pincode);
  const [showSavedToast, setShowSavedToast] = useState(false);

  const totalComplaints = complaints.length;
  const solvedComplaints = complaints.filter((c) => c.status === 'solved').length;
  const pendingComplaints = totalComplaints - solvedComplaints;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: UserProfile = {
      ...user,
      name: name.trim() || user.name,
      phone: phone.trim() || user.phone,
      address: address.trim() || user.address,
      pincode: pincode.trim() || user.pincode,
    };
    onUpdateUser(updated);
    setIsEditing(false);
    setShowSavedToast(true);
    setTimeout(() => setShowSavedToast(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Toast Notification */}
      {showSavedToast && (
        <div className="p-3 bg-blue-50 border border-blue-200 text-blue-800 rounded-xl text-sm font-semibold flex items-center gap-2 shadow-xs">
          <Check className="w-4 h-4 text-blue-600" />
          <span>Your profile details have been saved successfully!</span>
        </div>
      )}

      {/* Main Profile Card */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        {/* Cover banner in royal blue / indigo gradient */}
        <div className="h-32 bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 relative">
          <div className="absolute right-4 top-4 bg-white/20 backdrop-blur-xs px-3 py-1 rounded-full text-xs font-semibold text-white flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5" />
            <span>Verified Citizen Profile</span>
          </div>
        </div>

        <div className="px-6 pb-6 pt-0 relative">
          {/* Avatar and basic info */}
          <div className="flex flex-wrap items-end justify-between gap-4 -mt-12 mb-6">
            <div className="flex items-end gap-4">
              <div className="relative">
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-24 h-24 rounded-2xl border-4 border-white shadow-md object-cover bg-slate-100"
                />
                {user.isGoogleUser && (
                  <div
                    title="Google Account"
                    className="absolute -bottom-1 -right-1 w-7 h-7 bg-white rounded-full p-1 shadow-xs border border-slate-200 flex items-center justify-center"
                  >
                    <svg className="w-4 h-4" viewBox="0 0 24 24">
                      <path
                        fill="#4285F4"
                        d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                      />
                      <path
                        fill="#34A853"
                        d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                      />
                      <path
                        fill="#FBBC05"
                        d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                      />
                      <path
                        fill="#EA4335"
                        d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                      />
                    </svg>
                  </div>
                )}
              </div>

              <div>
                <h1 className="text-2xl font-bold text-slate-900">{user.name}</h1>
                <p className="text-sm text-slate-500 flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>{user.email}</span>
                </p>
              </div>
            </div>

            <div>
              {!isEditing ? (
                <button
                  type="button"
                  onClick={() => setIsEditing(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 transition-colors"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Edit Details</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-3.5 py-2 rounded-xl text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 transition-colors"
                >
                  Cancel
                </button>
              )}
            </div>
          </div>

          {/* User Complaint Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-600">Total Submitted</span>
                <FileText className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl font-extrabold text-slate-900 mt-2">{totalComplaints}</div>
              <div className="text-[11px] text-slate-500 mt-0.5">Complaints in your account</div>
            </div>

            <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-blue-800">In Progress</span>
                <Clock className="w-4 h-4 text-blue-600" />
              </div>
              <div className="text-2xl font-extrabold text-blue-900 mt-2">{pendingComplaints}</div>
              <div className="text-[11px] text-blue-700 mt-0.5">Under review & work</div>
            </div>

            <div className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-indigo-800">Solved Issues</span>
                <Sparkles className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-2xl font-extrabold text-indigo-900 mt-2">{solvedComplaints}</div>
              <div className="text-[11px] text-indigo-700 mt-0.5">Completely fixed</div>
            </div>
          </div>

          {/* Details / Edit Form */}
          {isEditing ? (
            <form onSubmit={handleSave} className="space-y-4 pt-2 border-t border-slate-200">
              <h3 className="text-sm font-bold text-slate-800">Update Profile Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Full Name
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Phone Number
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Street & Area Address
                  </label>
                  <input
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Area Pincode (6 digits)
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={pincode}
                    onChange={(e) => setPincode(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm"
                >
                  Save Changes
                </button>
              </div>
            </form>
          ) : (
            <div className="border-t border-slate-200 pt-5 space-y-4">
              <h3 className="text-sm font-bold text-slate-800">Your Contact & Location Details</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <User className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Citizen Name</div>
                    <div className="font-semibold text-slate-800">{user.name}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <Phone className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Phone Number</div>
                    <div className="font-semibold text-slate-800">{user.phone || 'Not provided'}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <MapPin className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Home / Area Address</div>
                    <div className="font-semibold text-slate-800">{user.address || 'Not specified'}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <div className="w-5 h-5 rounded-md bg-blue-100 text-blue-700 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                    #
                  </div>
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Area Pincode</div>
                    <div className="font-bold text-blue-700">{user.pincode}</div>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100 sm:col-span-2">
                  <Calendar className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
                  <div>
                    <div className="text-xs text-slate-500 font-medium">Registered Since</div>
                    <div className="font-semibold text-slate-800">{user.joinedDate}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Quick Action Footer */}
      <div className="p-5 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl border border-blue-200 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h4 className="font-bold text-blue-900 text-sm">Have an issue in your street?</h4>
          <p className="text-xs text-blue-700">
            Submit a complaint with photos and location pin. It only takes 2 minutes.
          </p>
        </div>
        <button
          onClick={onFileComplaintClick}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-xl shadow-xs transition-colors"
        >
          File a Complaint Now
        </button>
      </div>
    </div>
  );
};
