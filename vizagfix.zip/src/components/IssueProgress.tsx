import React, { useState } from 'react';
import { Complaint, ComplaintStatus } from '../types';
import {
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  AlertCircle,
  MessageSquare,
  FileText,
  UserCheck,
  ChevronDown,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

interface IssueProgressProps {
  complaints: Complaint[];
  selectedComplaintId?: string;
  onSelectComplaint: (id: string) => void;
  onUpdateStatus: (id: string, newStatus: ComplaintStatus, note?: string) => void;
  onFileNewComplaint: () => void;
}

const STEPS: { status: ComplaintStatus; label: string; desc: string }[] = [
  {
    status: 'received',
    label: '1. Received',
    desc: 'Complaint logged in system',
  },
  {
    status: 'checking',
    label: '2. Checking Issue',
    desc: 'Officer assigned & inspected',
  },
  {
    status: 'in_progress',
    label: '3. Work in Progress',
    desc: 'Repair team on site',
  },
  {
    status: 'solved',
    label: '4. Solved & Fixed',
    desc: 'Completed and verified',
  },
];

const STATUS_ORDER: Record<ComplaintStatus, number> = {
  received: 0,
  checking: 1,
  in_progress: 2,
  solved: 3,
};

export const IssueProgress: React.FC<IssueProgressProps> = ({
  complaints,
  selectedComplaintId,
  onSelectComplaint,
  onUpdateStatus,
  onFileNewComplaint,
}) => {
  // If complaint id not specified, pick latest active complaint, or first complaint
  const activeComplaint =
    complaints.find((c) => c.id === selectedComplaintId) ||
    complaints.find((c) => c.status !== 'solved') ||
    complaints[0];

  const [citizenNoteText, setCitizenNoteText] = useState('');
  const [showNoteInput, setShowNoteInput] = useState(false);

  if (!activeComplaint) {
    return (
      <div className="max-w-2xl mx-auto py-12 text-center bg-white rounded-2xl border border-slate-200 p-8 space-y-4">
        <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto">
          <FileText className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-bold text-slate-800">No Complaints Found</h2>
        <p className="text-sm text-slate-500">
          You haven't submitted any complaints yet. Report a problem in your street to start tracking progress.
        </p>
        <button
          onClick={onFileNewComplaint}
          className="px-6 py-2.5 bg-blue-600 text-white font-semibold rounded-xl text-sm hover:bg-blue-700 shadow-sm transition-colors"
        >
          File a Complaint
        </button>
      </div>
    );
  }

  const currentStepIndex = STATUS_ORDER[activeComplaint.status];

  const handleNextStepSimulation = () => {
    const sequence: ComplaintStatus[] = ['received', 'checking', 'in_progress', 'solved'];
    const nextIdx = Math.min(currentStepIndex + 1, sequence.length - 1);
    const nextStatus = sequence[nextIdx];
    const notes: Record<ComplaintStatus, string> = {
      received: 'Complaint logged in the portal.',
      checking: 'Ward officer inspected the site and verified repairs.',
      in_progress: 'Maintenance team and equipment deployed on location.',
      solved: 'Civic repairs completed successfully. Resolved and closed.',
    };
    onUpdateStatus(activeComplaint.id, nextStatus, notes[nextStatus]);
  };

  const handleCitizenMarkSolved = () => {
    onUpdateStatus(
      activeComplaint.id,
      'solved',
      'Citizen confirmed issue is resolved in their neighborhood.'
    );
  };

  const handleAddCitizenNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!citizenNoteText.trim()) return;
    onUpdateStatus(
      activeComplaint.id,
      activeComplaint.status,
      `Citizen Note: ${citizenNoteText.trim()}`
    );
    setCitizenNoteText('');
    setShowNoteInput(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Switch Active Complaint Selector */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Tracking Complaint:
          </span>
          <div className="relative">
            <select
              value={activeComplaint.id}
              onChange={(e) => onSelectComplaint(e.target.value)}
              className="appearance-none bg-slate-50 hover:bg-slate-100 border border-slate-300 font-bold text-slate-800 text-sm py-2 pl-3 pr-8 rounded-xl cursor-pointer focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {complaints.map((c) => (
                <option key={c.id} value={c.id}>
                  #{c.id} - {c.title.substring(0, 30)}... ({c.status === 'solved' ? 'Solved' : 'In Progress'})
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-slate-500 absolute right-2.5 top-3 pointer-events-none" />
          </div>
        </div>

        <div className="flex items-center gap-2">
          {activeComplaint.status === 'solved' ? (
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300 flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-blue-600" />
              <span>Solved & Closed</span>
            </span>
          ) : (
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-sky-100 text-sky-800 border border-sky-300 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-sky-700" />
              <span>In Progress ({activeComplaint.status})</span>
            </span>
          )}
        </div>
      </div>

      {/* Main Issue Header Card */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-md bg-slate-100 text-slate-700 font-bold text-xs">
              #{activeComplaint.id}
            </span>
            <span className="px-2.5 py-0.5 rounded-md bg-blue-50 text-blue-700 font-semibold text-xs border border-blue-200">
              {activeComplaint.category}
            </span>
            {activeComplaint.urgency === 'Urgent' && (
              <span className="px-2.5 py-0.5 rounded-md bg-rose-50 text-rose-700 font-semibold text-xs border border-rose-200">
                Urgent Priority
              </span>
            )}
            <span className="text-xs text-slate-400 ml-auto flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5" />
              Filed on {activeComplaint.createdAt}
            </span>
          </div>

          <h1 className="text-xl sm:text-2xl font-bold text-slate-900">
            {activeComplaint.title}
          </h1>

          <p className="text-sm text-slate-600 mt-2 leading-relaxed">
            {activeComplaint.description}
          </p>
        </div>

        {/* Location & Pincode Badge */}
        <div className="flex flex-wrap items-center gap-4 pt-3 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-1.5 text-slate-700 font-medium">
            <MapPin className="w-4 h-4 text-blue-600" />
            <span>{activeComplaint.location.address}</span>
          </div>
          <div className="bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200 font-semibold text-blue-800">
            Pincode: {activeComplaint.location.pincode}
          </div>
          {activeComplaint.location.landmark && (
            <div className="text-slate-500">
              Landmark: <span className="text-slate-700 font-medium">{activeComplaint.location.landmark}</span>
            </div>
          )}
        </div>
      </div>

      {/* Visual Step-by-Step Progress Bar */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-slate-900">
            Progress of This Issue
          </h2>
          <span className="text-xs text-slate-500 font-medium">
            Last Updated: {activeComplaint.updatedAt}
          </span>
        </div>

        {/* Progress Stepper Bar */}
        <div className="relative py-2">
          {/* Horizontal Track Line */}
          <div className="hidden sm:block absolute top-1/2 left-8 right-8 h-1.5 bg-slate-200 -translate-y-1/2 rounded-full z-0">
            <div
              className="h-full bg-blue-600 rounded-full transition-all duration-500"
              style={{
                width: `${(currentStepIndex / (STEPS.length - 1)) * 100}%`,
              }}
            />
          </div>

          {/* Stepper Nodes */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 relative z-10">
            {STEPS.map((step, idx) => {
              const isPassed = currentStepIndex >= idx;
              const isCurrent = currentStepIndex === idx;

              return (
                <div
                  key={step.status}
                  className={`flex sm:flex-col items-center sm:text-center gap-3 sm:gap-2 p-3 sm:p-2 rounded-xl transition-all ${
                    isCurrent
                      ? 'bg-blue-50/80 border border-blue-200'
                      : 'bg-transparent'
                  }`}
                >
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shadow-xs transition-colors shrink-0 ${
                      isPassed
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-200 text-slate-500 border border-slate-300'
                    }`}
                  >
                    {isPassed ? (
                      <CheckCircle2 className="w-5 h-5" />
                    ) : (
                      <span>{idx + 1}</span>
                    )}
                  </div>

                  <div>
                    <div
                      className={`text-xs font-bold ${
                        isCurrent
                          ? 'text-blue-900'
                          : isPassed
                          ? 'text-slate-800'
                          : 'text-slate-400'
                      }`}
                    >
                      {step.label}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {step.desc}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Simple Plain-English Status Explanation Box */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
          <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
            Current Status Explanation
          </div>
          <div className="text-sm font-semibold text-slate-900">
            {activeComplaint.status === 'received' &&
              'We have received your complaint and registered it in the system. An officer is being assigned.'}
            {activeComplaint.status === 'checking' &&
              'An officer from the municipal department has inspected the issue and initiated work approval.'}
            {activeComplaint.status === 'in_progress' &&
              'Work is actively in progress. Repair workers and necessary materials are currently at the site.'}
            {activeComplaint.status === 'solved' &&
              'The issue has been completely repaired and verified. This complaint is now solved!'}
          </div>
        </div>

        {/* Action Controls for Citizen */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100">
          <div className="flex items-center gap-2">
            {activeComplaint.status !== 'solved' ? (
              <button
                type="button"
                onClick={handleCitizenMarkSolved}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Issue is Fixed! (Mark as Solved)</span>
              </button>
            ) : (
              <div className="text-xs font-semibold text-blue-700 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                <span>This problem is marked solved</span>
              </div>
            )}

            <button
              type="button"
              onClick={() => setShowNoteInput(!showNoteInput)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
            >
              <MessageSquare className="w-4 h-4 text-blue-600" />
              <span>Add a Note / Question</span>
            </button>
          </div>

          {/* Quick Simulation Button so User can test progression */}
          {activeComplaint.status !== 'solved' && (
            <button
              type="button"
              onClick={handleNextStepSimulation}
              className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 text-xs font-semibold rounded-lg flex items-center gap-1"
            >
              <span>Advance Progress Step</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Note Input Box */}
        {showNoteInput && (
          <form onSubmit={handleAddCitizenNote} className="p-3 bg-blue-50/50 rounded-xl border border-blue-200 space-y-2">
            <label className="block text-xs font-semibold text-slate-700">
              Add your note or question about this complaint:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={citizenNoteText}
                onChange={(e) => setCitizenNoteText(e.target.value)}
                placeholder="e.g. Street light is still not turning on tonight..."
                className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                className="px-4 py-1.5 bg-blue-600 text-white font-semibold text-xs rounded-lg hover:bg-blue-700"
              >
                Post Note
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Two Column Layout: Officer Info & Photo, and Timeline */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Officer Assigned & Photos */}
        <div className="space-y-4 md:col-span-1">
          {/* Officer Card */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <UserCheck className="w-4 h-4 text-blue-600" />
              <span>Assigned Officer</span>
            </h3>

            <div className="space-y-1 text-xs">
              <div className="font-bold text-slate-900 text-sm">
                {activeComplaint.assignedOfficer?.name || 'Ward Officer'}
              </div>
              <div className="text-slate-500">
                {activeComplaint.assignedOfficer?.department || 'Municipal Corporation'}
              </div>
              <div className="text-blue-700 font-medium pt-1">
                Helpline: {activeComplaint.assignedOfficer?.phone || '+91 94401 22334'}
              </div>
            </div>
          </div>

          {/* Photos Submitted */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Photos of this Issue ({activeComplaint.photos.length})
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {activeComplaint.photos.map((img, i) => (
                <a
                  key={i}
                  href={img}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-lg overflow-hidden border border-slate-200 aspect-video block bg-slate-100 hover:opacity-90"
                >
                  <img src={img} alt="Issue photo" className="w-full h-full object-cover" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Timeline of All Updates */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs md:col-span-2 space-y-4">
          <h3 className="text-base font-bold text-slate-900">
            Timeline of Events & Actions
          </h3>

          <div className="space-y-4 relative before:absolute before:top-2 before:bottom-2 before:left-3.5 before:w-0.5 before:bg-slate-200">
            {activeComplaint.updates.map((upd) => (
              <div key={upd.id} className="relative pl-8">
                <div className="absolute left-1.5 top-1.5 w-4 h-4 rounded-full bg-blue-600 border-2 border-white shadow-xs" />
                <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80 space-y-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-bold text-xs text-slate-900">
                      {upd.title}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {upd.date}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    {upd.note}
                  </p>
                  {upd.officerName && (
                    <div className="text-[11px] text-blue-700 font-medium pt-1">
                      By: {upd.officerName} {upd.department ? `(${upd.department})` : ''}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
