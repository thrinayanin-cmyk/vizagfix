import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import { MapPin, Navigation, Compass, Loader2 } from 'lucide-react';

interface LocationPickerMapProps {
  selectedLocation: {
    lat: number;
    lng: number;
    address: string;
    pincode: string;
  };
  onLocationChange: (loc: { lat: number; lng: number; address: string; pincode: string }) => void;
}

// Preset popular areas for quick one-click selection
const QUICK_AREAS = [
  { name: 'MVP Colony', pincode: '530017', lat: 17.7294, lng: 83.3155 },
  { name: 'Dwaraka Nagar', pincode: '530016', lat: 17.7262, lng: 83.3056 },
  { name: 'Beach Road', pincode: '530002', lat: 17.7121, lng: 83.3214 },
  { name: 'Madhurawada', pincode: '530048', lat: 17.8188, lng: 83.3512 },
  { name: 'Gajuwaka', pincode: '530026', lat: 17.6908, lng: 83.2185 },
];

// Clean custom SVG marker in royal blue (strictly no orange, no green!)
const createCustomIcon = () => {
  return L.divIcon({
    className: 'custom-pin-marker',
    html: `
      <div style="position: relative; display: flex; align-items: center; justify-content: center; width: 36px; height: 36px;">
        <div style="position: absolute; width: 36px; height: 36px; background-color: #2563eb; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); box-shadow: 0 4px 10px rgba(37,99,235,0.4); border: 2.5px solid #ffffff;"></div>
        <div style="position: absolute; width: 12px; height: 12px; background-color: #ffffff; border-radius: 50%; z-index: 2;"></div>
      </div>
    `,
    iconSize: [36, 36],
    iconAnchor: [18, 36],
    popupAnchor: [0, -36],
  });
};

export const LocationPickerMap: React.FC<LocationPickerMapProps> = ({
  selectedLocation,
  onLocationChange,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isFetchingAddress, setIsFetchingAddress] = useState(false);

  // Reverse geocode coordinate to get street and pincode
  const reverseGeocode = async (lat: number, lng: number) => {
    setIsFetchingAddress(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=18&addressdetails=1`,
        {
          headers: {
            'Accept-Language': 'en',
          },
        }
      );
      if (response.ok) {
        const data = await response.json();
        const addressData = data.address || {};
        const road = addressData.road || addressData.suburb || addressData.neighbourhood || 'Selected Location';
        const suburb = addressData.suburb || addressData.city_district || addressData.city || '';
        const detectedPincode = addressData.postcode || selectedLocation.pincode || '530017';
        const formattedAddress = [road, suburb].filter(Boolean).join(', ') || data.display_name?.split(',').slice(0, 3).join(', ');

        onLocationChange({
          lat,
          lng,
          address: formattedAddress || selectedLocation.address,
          pincode: detectedPincode,
        });
      }
    } catch {
      // Offline fallback: keep existing address or simple coordinates
      onLocationChange({
        lat,
        lng,
        address: selectedLocation.address || `Location near (${lat.toFixed(4)}, ${lng.toFixed(4)})`,
        pincode: selectedLocation.pincode || '530017',
      });
    } finally {
      setIsFetchingAddress(false);
    }
  };

  useEffect(() => {
    if (!mapContainerRef.current) return;
    if (mapInstanceRef.current) return;

    // Initialize Leaflet map
    const initialLat = selectedLocation.lat || 17.7294;
    const initialLng = selectedLocation.lng || 83.3155;

    const map = L.map(mapContainerRef.current, {
      center: [initialLat, initialLng],
      zoom: 14,
      zoomControl: true,
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 19,
    }).addTo(map);

    const marker = L.marker([initialLat, initialLng], {
      icon: createCustomIcon(),
      draggable: true,
    }).addTo(map);

    marker.bindPopup('<b>Selected Issue Location</b><br/>You can drag this pin or click anywhere').openPopup();

    // On marker drag
    marker.on('dragend', () => {
      const pos = marker.getLatLng();
      reverseGeocode(pos.lat, pos.lng);
    });

    // On map click
    map.on('click', (e: L.LeafletMouseEvent) => {
      const { lat, lng } = e.latlng;
      marker.setLatLng([lat, lng]);
      map.panTo([lat, lng]);
      reverseGeocode(lat, lng);
    });

    mapInstanceRef.current = map;
    markerRef.current = marker;

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  // Update marker position if coordinates change externally
  useEffect(() => {
    if (markerRef.current && mapInstanceRef.current) {
      const currentPos = markerRef.current.getLatLng();
      if (
        Math.abs(currentPos.lat - selectedLocation.lat) > 0.0001 ||
        Math.abs(currentPos.lng - selectedLocation.lng) > 0.0001
      ) {
        markerRef.current.setLatLng([selectedLocation.lat, selectedLocation.lng]);
        mapInstanceRef.current.panTo([selectedLocation.lat, selectedLocation.lng]);
      }
    }
  }, [selectedLocation.lat, selectedLocation.lng]);

  // Use GPS location
  const handleUseCurrentLocation = () => {
    if (!navigator.geolocation) {
      alert('Location services are not available on this browser.');
      return;
    }
    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        const { latitude, longitude } = pos.coords;
        if (mapInstanceRef.current && markerRef.current) {
          mapInstanceRef.current.setView([latitude, longitude], 16);
          markerRef.current.setLatLng([latitude, longitude]);
          reverseGeocode(latitude, longitude);
        }
      },
      () => {
        setIsLocating(false);
        // Fallback to default area
        if (mapInstanceRef.current && markerRef.current) {
          mapInstanceRef.current.setView([17.7294, 83.3155], 15);
          markerRef.current.setLatLng([17.7294, 83.3155]);
          reverseGeocode(17.7294, 83.3155);
        }
      },
      { timeout: 7000 }
    );
  };

  const handleSelectAreaPreset = (area: typeof QUICK_AREAS[0]) => {
    if (mapInstanceRef.current && markerRef.current) {
      mapInstanceRef.current.setView([area.lat, area.lng], 15);
      markerRef.current.setLatLng([area.lat, area.lng]);
      onLocationChange({
        lat: area.lat,
        lng: area.lng,
        address: `${area.name}, Main Road`,
        pincode: area.pincode,
      });
    }
  };

  return (
    <div className="space-y-3">
      {/* Top Map Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600">
          <Compass className="w-4 h-4 text-blue-600" />
          <span>Click anywhere on the map or drag the blue pin to mark the exact spot</span>
        </div>
        <button
          type="button"
          onClick={handleUseCurrentLocation}
          disabled={isLocating}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors shadow-xs"
        >
          {isLocating ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Navigation className="w-3.5 h-3.5" />
          )}
          <span>{isLocating ? 'Finding you...' : 'Use My Current Location'}</span>
        </button>
      </div>

      {/* Quick Select Buttons */}
      <div className="flex flex-wrap items-center gap-1.5">
        <span className="text-xs text-slate-500 font-medium">Quick Pick Area:</span>
        {QUICK_AREAS.map((area) => (
          <button
            key={area.name}
            type="button"
            onClick={() => handleSelectAreaPreset(area)}
            className="px-2.5 py-1 text-xs font-medium rounded-md bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 border border-slate-200 transition-colors"
          >
            {area.name} ({area.pincode})
          </button>
        ))}
      </div>

      {/* Map Container */}
      <div className="relative w-full h-64 sm:h-72 rounded-xl overflow-hidden border-2 border-slate-200 shadow-inner">
        <div ref={mapContainerRef} className="w-full h-full" />
        {isFetchingAddress && (
          <div className="absolute top-3 right-3 bg-white/95 px-3 py-1.5 rounded-lg shadow-md border border-slate-200 flex items-center gap-2 text-xs font-medium text-blue-700 z-30">
            <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" />
            <span>Finding address & pincode...</span>
          </div>
        )}
      </div>

      {/* Selected Spot Details Bar */}
      <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
            <MapPin className="w-4 h-4" />
          </div>
          <div>
            <div className="font-semibold text-slate-800">
              {selectedLocation.address || 'Selected Spot on Map'}
            </div>
            <div className="text-slate-500">
              Coordinates: {selectedLocation.lat.toFixed(4)}, {selectedLocation.lng.toFixed(4)}
            </div>
          </div>
        </div>
        <div className="bg-white px-3 py-1.5 rounded-lg border border-slate-200 font-medium text-slate-700">
          Detected Pincode: <span className="font-bold text-blue-700">{selectedLocation.pincode || '530017'}</span>
        </div>
      </div>
    </div>
  );
};
