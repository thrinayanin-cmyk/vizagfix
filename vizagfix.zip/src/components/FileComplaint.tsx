import React, { useState } from 'react';
import { Complaint, ComplaintCategory, UserProfile } from '../types';
import { LocationPickerMap } from './LocationPickerMap';
import {
  Upload,
  X,
  CheckCircle2,
  AlertCircle,
  Lightbulb,
  Droplet,
  Trash2,
  Wrench,
  HelpCircle,
  ShieldAlert,
  ArrowRight,
  Plus,
  Image as ImageIcon,
} from 'lucide-react';

interface FileComplaintProps {
  currentUser: UserProfile;
  onSubmitSuccess: (complaint: Complaint) => void;
  onTrackComplaint: (complaintId: string) => void;
}

const CATEGORIES: {
  category: ComplaintCategory;
  label: string;
  desc: string;
  icon: React.ElementType;
}[] = [
  {
    category: 'Pothole & Roads',
    label: 'Roads & Potholes',
    desc: 'Damaged road, potholes, broken pavement',
    icon: Wrench,
  },
  {
    category: 'Street Lights',
    label: 'Street Light',
    desc: 'Light not working, blinking, broken pole',
    icon: Lightbulb,
  },
  {
    category: 'Garbage Cleanliness',
    label: 'Garbage & Waste',
    desc: 'Overflowing bin, street trash, sweeping needed',
    icon: Trash2,
  },
  {
    category: 'Water Supply & Leaks',
    label: 'Water Supply',
    desc: 'Pipe leak, low pressure, no water',
    icon: Droplet,
  },
  {
    category: 'Drainage & Sewers',
    label: 'Drain & Sewer',
    desc: 'Clogged drain, overflow, bad smell',
    icon: ShieldAlert,
  },
  {
    category: 'Other Problem',
    label: 'Other Problem',
    desc: 'Any other neighborhood problem',
    icon: HelpCircle,
  },
];

const SAMPLE_PHOTO_PRESETS = [
  {
    name: 'Sample Pothole Photo',
    url: 'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Sample Street Light Photo',
    url: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80',
  },
  {
    name: 'Sample Garbage Photo',
    url: 'https://images.unsplash.com/photo-1605600659908-0ef719419d41?auto=format&fit=crop&w=600&q=80',
  },
];

export const FileComplaint: React.FC<FileComplaintProps> = ({
  currentUser,
  onSubmitSuccess,
  onTrackComplaint,
}) => {
  // Form fields
  const [category, setCategory] = useState<ComplaintCategory>('Street Lights');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [urgency, setUrgency] = useState<'Normal' | 'Urgent'>('Normal');
  const [landmark, setLandmark] = useState('');

  // Location state
  const [location, setLocation] = useState({
    lat: 17.7294,
    lng: 83.3155,
    address: currentUser.address || 'MVP Colony, Sector 3',
    pincode: currentUser.pincode || '530017',
  });

  // Multiple photos state
  const [photos, setPhotos] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Success view state
  const [submittedComplaint, setSubmittedComplaint] = useState<Complaint | null>(null);

  // Handle local file uploads (supports multiple)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setPhotos((prev) => [...prev, event.target!.result as string]);
        }
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos((prev) => prev.filter((_, i) => i !== index));
  };

  const handleAddSamplePhoto = (sampleUrl: string) => {
    if (!photos.includes(sampleUrl)) {
      setPhotos((prev) => [...prev, sampleUrl]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!title.trim()) {
      setErrorMsg('Please enter a short title for the complaint.');
      return;
    }
    if (!description.trim()) {
      setErrorMsg('Please write a brief description of the issue.');
      return;
    }
    if (!location.pincode.trim() || location.pincode.trim().length !== 6) {
      setErrorMsg('Please provide a valid 6-digit area pincode.');
      return;
    }

    setIsSubmitting(true);

    const now = new Date();
    const dateStr = now.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });

    const newId = 'CMP-' + Math.floor(1000 + Math.random() * 9000);

    const newComplaint: Complaint = {
      id: newId,
      title: title.trim(),
      category: category,
      description: description.trim(),
      urgency: urgency,
      location: {
        lat: location.lat,
        lng: location.lng,
        address: location.address.trim() || 'Specified Area',
        pincode: location.pincode.trim(),
        landmark: landmark.trim() || undefined,
      },
      photos: photos.length > 0 ? photos : [SAMPLE_PHOTO_PRESETS[1].url],
      status: 'received',
      createdAt: dateStr,
      updatedAt: dateStr,
      estimatedDays: urgency === 'Urgent' ? 2 : 4,
      assignedOfficer: {
        name: 'Municipal Ward Inspector',
        department: 'Public Grievance Redressal Cell',
        phone: '+91 94401 22334',
      },
      updates: [
        {
          id: 'upd-' + Date.now(),
          date: dateStr,
          title: 'Complaint Received',
          note: 'Your complaint has been successfully registered and queued for officer inspection.',
          status: 'received',
        },
      ],
    };

    setTimeout(() => {
      setIsSubmitting(false);
      setSubmittedComplaint(newComplaint);
      onSubmitSuccess(newComplaint);
    }, 600);
  };

  const handleResetForAnother = () => {
    setTitle('');
    setDescription('');
    setLandmark('');
    setPhotos([]);
    setSubmittedComplaint(null);
    setErrorMsg('');
  };

  // If complaint was just submitted, show simple success card
  if (submittedComplaint) {
    return (
      <div className="max-w-2xl mx-auto py-8">
        <div className="bg-white rounded-2xl shadow-md border border-slate-200 p-8 text-center space-y-6">
          <div className="w-16 h-16 bg-blue-100 text-blue-700 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div>
            <span className="inline-block px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-800 border border-blue-200 mb-2">
              Complaint Number #{submittedComplaint.id}
            </span>
            <h2 className="text-2xl font-bold text-slate-900">
              Complaint Filed Successfully!
            </h2>
            <p className="text-sm text-slate-600 mt-2 max-w-md mx-auto">
              We have notified the municipal team for your area (Pincode: {submittedComplaint.location.pincode}).
              You can track every step of the work.
            </p>
          </div>

          {/* Quick Summary Card */}
          <div className="bg-slate-50 rounded-xl p-4 text-left border border-slate-200 space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500">Problem Title:</span>
              <span className="font-semibold text-slate-800">{submittedComplaint.title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Category:</span>
              <span className="font-semibold text-slate-800">{submittedComplaint.category}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Location:</span>
              <span className="font-semibold text-slate-800">{submittedComplaint.location.address}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Pincode:</span>
              <span className="font-bold text-blue-700">{submittedComplaint.location.pincode}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Estimated Resolution:</span>
              <span className="font-semibold text-slate-800">Within {submittedComplaint.estimatedDays} Days</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              onClick={() => onTrackComplaint(submittedComplaint.id)}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm shadow-sm flex items-center justify-center gap-2 transition-colors"
            >
              <span>Track This Issue Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={handleResetForAnother}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-sm flex items-center justify-center gap-2 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>File Another Complaint</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Title Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
        <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
          File a Complaint
        </h1>
        <p className="text-sm text-slate-600 mt-1">
          Tell us about the issue in simple words. Mark the exact spot on the map and check your area pincode.
        </p>
      </div>

      {errorMsg && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Step 1: Select Category */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center">
              1
            </div>
            <h2 className="text-base font-bold text-slate-900">
              What kind of problem is it?
            </h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {CATEGORIES.map((cat) => {
              const Icon = cat.icon;
              const isSelected = category === cat.category;
              return (
                <button
                  key={cat.category}
                  type="button"
                  onClick={() => setCategory(cat.category)}
                  className={`p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50/70 shadow-xs ring-2 ring-blue-500/20'
                      : 'border-slate-200 bg-slate-50/60 hover:bg-slate-100 hover:border-slate-300'
                  }`}
                >
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center mb-2 ${
                      isSelected
                        ? 'bg-blue-600 text-white'
                        : 'bg-white text-slate-700 border border-slate-200'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <div
                      className={`text-xs font-bold ${
                        isSelected ? 'text-blue-900' : 'text-slate-800'
                      }`}
                    >
                      {cat.label}
                    </div>
                    <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                      {cat.desc}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Title and Description */}
          <div className="space-y-3 pt-2">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Short Title <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g. Street light bulb fused near House 14"
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Description of the Problem <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Please explain what is broken and how it affects people in simple words..."
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* Urgency */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Urgency Level
              </label>
              <div className="flex gap-3">
                <label className="flex-1 cursor-pointer">
                  <input
                    type="radio"
                    name="urgency"
                    value="Normal"
                    checked={urgency === 'Normal'}
                    onChange={() => setUrgency('Normal')}
                    className="sr-only"
                  />
                  <div
                    className={`p-3 rounded-xl border text-center transition-all ${
                      urgency === 'Normal'
                        ? 'border-blue-600 bg-blue-50 text-blue-900 font-bold shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-xs font-bold">Standard Issue</div>
                    <div className="text-[11px] opacity-75">Within 3 - 5 days</div>
                  </div>
                </label>

                <label className="flex-1 cursor-pointer">
                  <input
                    type="radio"
                    name="urgency"
                    value="Urgent"
                    checked={urgency === 'Urgent'}
                    onChange={() => setUrgency('Urgent')}
                    className="sr-only"
                  />
                  <div
                    className={`p-3 rounded-xl border text-center transition-all ${
                      urgency === 'Urgent'
                        ? 'border-rose-600 bg-rose-50 text-rose-900 font-bold shadow-xs'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="text-xs font-bold">Urgent Issue</div>
                    <div className="text-[11px] opacity-75">Hazard or flood (1 - 2 days)</div>
                  </div>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Step 2: Location and Pincode */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center">
              2
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Where is the problem located?
              </h2>
              <p className="text-xs text-slate-500">
                Pick the spot on the map and make sure your area pincode is correct.
              </p>
            </div>
          </div>

          {/* Interactive Map */}
          <LocationPickerMap
            selectedLocation={location}
            onLocationChange={(newLoc) => setLocation(newLoc)}
          />

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Street / Area Address
              </label>
              <input
                type="text"
                value={location.address}
                onChange={(e) => setLocation({ ...location, address: e.target.value })}
                placeholder="e.g. Near Water Tank, Main Road"
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Area Pincode (Postal Code) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                maxLength={6}
                value={location.pincode}
                onChange={(e) => setLocation({ ...location, pincode: e.target.value })}
                placeholder="530017"
                required
                className="w-full px-3.5 py-2.5 text-sm rounded-xl border-2 border-blue-400 font-bold text-blue-900 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-blue-50/30"
              />
            </div>

            <div className="sm:col-span-3">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Landmark (Optional)
              </label>
              <input
                type="text"
                value={landmark}
                onChange={(e) => setLandmark(e.target.value)}
                placeholder="e.g. Opposite Community Hall, Behind School"
                className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>

        {/* Step 3: Photos of the Problem */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <div className="w-6 h-6 rounded-full bg-blue-600 text-white text-xs font-bold flex items-center justify-center">
              3
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Upload Photos of the Issue
              </h2>
              <p className="text-xs text-slate-500">
                You can upload more than one photo to help officers see the problem clearly.
              </p>
            </div>
          </div>

          {/* Photo Dropzone / Input */}
          <div className="space-y-3">
            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-2xl cursor-pointer bg-slate-50/70 hover:bg-blue-50/30 transition-colors">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-8 h-8 text-blue-600 mb-2" />
                <p className="text-xs font-semibold text-slate-700">
                  Click to select photos or take a picture
                </p>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Supports JPG, PNG (You can choose multiple photos)
                </p>
              </div>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>

            {/* Quick Demo Sample Photos */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <span className="text-xs text-slate-500 font-medium">Or add quick sample photo:</span>
              {SAMPLE_PHOTO_PRESETS.map((sample) => (
                <button
                  key={sample.name}
                  type="button"
                  onClick={() => handleAddSamplePhoto(sample.url)}
                  className="px-2.5 py-1 text-xs font-medium rounded-lg bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-700 border border-slate-200 transition-colors flex items-center gap-1"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>{sample.name}</span>
                </button>
              ))}
            </div>

            {/* Uploaded Photos Preview List */}
            {photos.length > 0 && (
              <div className="pt-2">
                <div className="text-xs font-bold text-slate-700 mb-2">
                  Uploaded Photos ({photos.length}):
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {photos.map((photo, idx) => (
                    <div
                      key={idx}
                      className="relative rounded-xl overflow-hidden border border-slate-200 bg-slate-100 group aspect-video"
                    >
                      <img
                        src={photo}
                        alt={`Problem photo ${idx + 1}`}
                        className="w-full h-full object-cover"
                      />
                      <button
                        type="button"
                        onClick={() => handleRemovePhoto(idx)}
                        className="absolute top-1 right-1 p-1 bg-slate-900/80 hover:bg-rose-600 text-white rounded-full transition-colors"
                        title="Remove photo"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex items-center justify-between gap-4 pt-2">
          <div className="text-xs text-slate-500">
            By submitting, your complaint will be logged with local municipal ward authorities.
          </div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white font-bold text-sm shadow-md transition-all flex items-center gap-2 shrink-0"
          >
            {isSubmitting ? (
              <span>Submitting Complaint...</span>
            ) : (
              <>
                <span>Submit Complaint</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
