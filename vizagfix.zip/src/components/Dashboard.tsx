import React from 'react';
import { UserProfile, Complaint } from '../types';
import {
  PlusCircle,
  Activity,
  History,
  CheckCircle2,
  Clock,
  MapPin,
  ArrowRight,
  ShieldCheck,
  Building,
  FileText,
  User,
  Sparkles,
  PhoneCall,
} from 'lucide-react';

interface DashboardProps {
  currentUser: UserProfile;
  complaints: Complaint[];
  onNavigate: (tab: string, complaintId?: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  currentUser,
  complaints,
  onNavigate,
}) => {
  const totalComplaints = complaints.length;
  const solvedComplaints = complaints.filter((c) => c.status === 'solved').length;
  const inProgressComplaints = totalComplaints - solvedComplaints;

  // The latest active complaint (or first one)
  const currentActiveComplaint =
    complaints.find((c) => c.status !== 'solved') || complaints[0];

  const recentComplaints = complaints.slice(0, 4);

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Welcome Hero Banner in Deep Royal Blue & Indigo */}
      <div className="rounded-3xl bg-gradient-to-r from-blue-700 via-blue-800 to-indigo-900 text-white p-6 sm:p-8 shadow-sm relative overflow-hidden">
        {/* Subtle decorative circles */}
        <div className="absolute -right-8 -bottom-8 w-60 h-60 rounded-full bg-white/5 pointer-events-none" />
        <div className="absolute right-40 -top-10 w-40 h-40 rounded-full bg-white/5 pointer-events-none" />

        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/15 backdrop-blur-xs text-xs font-semibold text-blue-100 border border-white/20">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Citizen Public Service Portal</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Hello, {currentUser.name.split(' ')[0]}!
          </h1>
          <p className="text-blue-100 text-sm sm:text-base leading-relaxed">
            Report broken street lights, potholes, garbage, or water leaks in your area.
            Drop a pin on the map, provide your pincode, and track the repair live.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-3">
            <button
              onClick={() => onNavigate('file_complaint')}
              className="px-6 py-3 rounded-xl bg-white text-blue-800 font-bold text-sm shadow-md hover:bg-blue-50 transition-all flex items-center gap-2"
            >
              <PlusCircle className="w-4 h-4 text-blue-600" />
              <span>File a New Complaint</span>
            </button>

            <button
              onClick={() => onNavigate('track_progress')}
              className="px-5 py-3 rounded-xl bg-blue-600/60 hover:bg-blue-600/80 text-white font-semibold text-sm border border-white/20 transition-all flex items-center gap-2"
            >
              <Activity className="w-4 h-4" />
              <span>Check Progress</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Active Complaints */}
        <div
          onClick={() => onNavigate('track_progress')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-blue-400 cursor-pointer transition-all flex items-center justify-between"
        >
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              In Progress
            </span>
            <div className="text-3xl font-black text-slate-900 mt-1">
              {inProgressComplaints}
            </div>
            <p className="text-xs text-blue-700 mt-1 font-medium flex items-center gap-1">
              <span>Being checked & repaired</span>
              <ArrowRight className="w-3 h-3" />
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-700 flex items-center justify-center border border-sky-100">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        {/* Solved Complaints */}
        <div
          onClick={() => onNavigate('history')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-blue-400 cursor-pointer transition-all flex items-center justify-between"
        >
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Solved & Fixed
            </span>
            <div className="text-3xl font-black text-blue-800 mt-1">
              {solvedComplaints}
            </div>
            <p className="text-xs text-blue-700 mt-1 font-medium flex items-center gap-1">
              <span>Verified completed</span>
              <ArrowRight className="w-3 h-3" />
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-100">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        {/* Total Filed */}
        <div
          onClick={() => onNavigate('history')}
          className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-blue-400 cursor-pointer transition-all flex items-center justify-between"
        >
          <div>
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Total Complaints
            </span>
            <div className="text-3xl font-black text-slate-900 mt-1">
              {totalComplaints}
            </div>
            <p className="text-xs text-slate-500 mt-1 font-medium flex items-center gap-1">
              <span>All past submissions</span>
              <ArrowRight className="w-3 h-3" />
            </p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center border border-slate-200">
            <FileText className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Current Issue Spotlight & User Profile Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Current Active Issue Spotlight (2 cols) */}
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full bg-blue-600 animate-pulse" />
              <h2 className="text-base font-bold text-slate-900">
                Current Issue in Progress
              </h2>
            </div>
            <button
              onClick={() => onNavigate('track_progress')}
              className="text-xs font-bold text-blue-700 hover:text-blue-800 flex items-center gap-1"
            >
              <span>View Full Tracker</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {currentActiveComplaint ? (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-800 font-bold text-xs">
                    #{currentActiveComplaint.id}
                  </span>
                  <span className="text-xs font-semibold text-slate-600">
                    {currentActiveComplaint.category}
                  </span>
                </div>

                {currentActiveComplaint.status === 'solved' ? (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300">
                    Solved
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-100 text-sky-800 border border-sky-300">
                    In Progress ({currentActiveComplaint.status})
                  </span>
                )}
              </div>

              <h3 className="font-bold text-slate-900 text-sm">
                {currentActiveComplaint.title}
              </h3>

              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-600">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-blue-600" />
                  {currentActiveComplaint.location.address}
                </span>
                <span className="font-bold text-blue-700">
                  PIN: {currentActiveComplaint.location.pincode}
                </span>
              </div>

              {/* Progress mini indicator */}
              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between text-xs font-medium text-slate-600">
                  <span>Current Step:</span>
                  <span className="font-bold text-blue-800">
                    {currentActiveComplaint.status === 'received' && '1 of 4: Received'}
                    {currentActiveComplaint.status === 'checking' && '2 of 4: Checking Issue'}
                    {currentActiveComplaint.status === 'in_progress' && '3 of 4: Work in Progress'}
                    {currentActiveComplaint.status === 'solved' && '4 of 4: Solved'}
                  </span>
                </div>
                <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
                  <div
                    className="h-full bg-blue-600 rounded-full"
                    style={{
                      width:
                        currentActiveComplaint.status === 'received'
                          ? '25%'
                          : currentActiveComplaint.status === 'checking'
                          ? '50%'
                          : currentActiveComplaint.status === 'in_progress'
                          ? '75%'
                          : '100%',
                    }}
                  />
                </div>
              </div>

              <div className="pt-1 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  Last update: {currentActiveComplaint.updatedAt}
                </span>
                <button
                  onClick={() => onNavigate('track_progress', currentActiveComplaint.id)}
                  className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-colors"
                >
                  Track Live Progress
                </button>
              </div>
            </div>
          ) : (
            <div className="p-6 text-center text-slate-500 text-xs">
              No active complaints right now. Click "File a New Complaint" to report one.
            </div>
          )}

          {/* Quick Helper for Beginners */}
          <div className="pt-2">
            <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
              How VizagFix Works (3 Simple Steps)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="font-bold text-slate-800 flex items-center gap-1.5 mb-1">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">1</span>
                  <span>Report Problem</span>
                </div>
                <p className="text-slate-500 text-[11px]">
                  Take a photo and write what is broken.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="font-bold text-slate-800 flex items-center gap-1.5 mb-1">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">2</span>
                  <span>Set Map & Pincode</span>
                </div>
                <p className="text-slate-500 text-[11px]">
                  Drop a pin so workers reach the exact spot.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <div className="font-bold text-slate-800 flex items-center gap-1.5 mb-1">
                  <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px]">3</span>
                  <span>Track Until Solved</span>
                </div>
                <p className="text-slate-500 text-[11px]">
                  See real-time repair updates on your phone.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* User Profile Mini Widget (1 col) */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                My Citizen Profile
              </span>
              <button
                onClick={() => onNavigate('profile')}
                className="text-xs font-bold text-blue-700 hover:underline"
              >
                View Full
              </button>
            </div>

            <div className="pt-4 flex items-center gap-3">
              <img
                src={currentUser.avatarUrl}
                alt={currentUser.name}
                className="w-14 h-14 rounded-2xl object-cover border border-blue-200 shadow-xs"
              />
              <div>
                <h3 className="font-bold text-slate-900 text-base">
                  {currentUser.name}
                </h3>
                <p className="text-xs text-slate-500">{currentUser.email}</p>
                <div className="mt-1 inline-block px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 text-[11px] font-semibold">
                  Verified Resident
                </div>
              </div>
            </div>

            <div className="space-y-2.5 pt-4 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Phone:</span>
                <span className="font-semibold text-slate-800">{currentUser.phone}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Area Address:</span>
                <span className="font-semibold text-slate-800 text-right truncate max-w-[170px]">
                  {currentUser.address}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Area Pincode:</span>
                <span className="font-bold text-blue-700">{currentUser.pincode}</span>
              </div>
            </div>
          </div>

          <div className="pt-4 space-y-2">
            <button
              onClick={() => onNavigate('profile')}
              className="w-full py-2 px-3 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center justify-center gap-1.5"
            >
              <User className="w-3.5 h-3.5 text-blue-600" />
              <span>Edit My Profile Details</span>
            </button>
          </div>
        </div>
      </div>

      {/* Recent Complaints Summary List */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Recent Complaints
            </h2>
            <p className="text-xs text-slate-500">
              Overview of issues you filed and whether they are solved or not.
            </p>
          </div>

          <button
            onClick={() => onNavigate('history')}
            className="text-xs font-bold text-blue-700 hover:text-blue-800 flex items-center gap-1"
          >
            <span>See All History ({complaints.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="divide-y divide-slate-100">
          {recentComplaints.map((item) => (
            <div
              key={item.id}
              className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 rounded-xl px-2 transition-colors"
            >
              <div className="flex items-start gap-3">
                <div className="w-12 h-12 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0">
                  <img
                    src={item.photos[0] || 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=200&q=80'}
                    alt="Photo"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-800">
                      #{item.id}
                    </span>
                    <span className="text-[11px] font-medium text-slate-500">
                      {item.category}
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-slate-900">
                    {item.title}
                  </h4>
                  <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      {item.location.address}
                    </span>
                    <span className="text-blue-700 font-semibold">
                      PIN: {item.location.pincode}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 self-end sm:self-center">
                {item.status === 'solved' ? (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                    <span>Solved</span>
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-100 text-sky-800 border border-sky-300 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-sky-700" />
                    <span>In Progress</span>
                  </span>
                )}

                <button
                  onClick={() => onNavigate('track_progress', item.id)}
                  className="px-3 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                >
                  Track
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
