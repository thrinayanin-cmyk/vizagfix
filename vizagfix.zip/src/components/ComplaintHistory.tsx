import React, { useState } from 'react';
import { Complaint } from '../types';
import {
  Search,
  Filter,
  CheckCircle2,
  Clock,
  MapPin,
  Calendar,
  Eye,
  ArrowRight,
  X,
  FileText,
  AlertCircle,
} from 'lucide-react';

interface ComplaintHistoryProps {
  complaints: Complaint[];
  onTrackComplaint: (id: string) => void;
  onFileNewComplaint: () => void;
}

export const ComplaintHistory: React.FC<ComplaintHistoryProps> = ({
  complaints,
  onTrackComplaint,
  onFileNewComplaint,
}) => {
  const [filter, setFilter] = useState<'all' | 'in_progress' | 'solved'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [viewComplaint, setViewComplaint] = useState<Complaint | null>(null);

  // Filter complaints
  const filtered = complaints.filter((c) => {
    // Status filter
    if (filter === 'solved' && c.status !== 'solved') return false;
    if (filter === 'in_progress' && c.status === 'solved') return false;

    // Search query filter (matches ID, title, address, pincode, category)
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchId = c.id.toLowerCase().includes(q);
      const matchTitle = c.title.toLowerCase().includes(q);
      const matchAddress = c.location.address.toLowerCase().includes(q);
      const matchPincode = c.location.pincode.toLowerCase().includes(q);
      const matchCategory = c.category.toLowerCase().includes(q);
      return matchId || matchTitle || matchAddress || matchPincode || matchCategory;
    }
    return true;
  });

  const totalCount = complaints.length;
  const solvedCount = complaints.filter((c) => c.status === 'solved').length;
  const inProgressCount = totalCount - solvedCount;

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      {/* Header and Title */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">
            Complaint History
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            See all your past and current complaints, and check if they are solved or in progress.
          </p>
        </div>

        <button
          onClick={onFileNewComplaint}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-sm rounded-xl shadow-xs transition-colors"
        >
          File New Complaint
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto">
            <button
              onClick={() => setFilter('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                filter === 'all'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All Complaints ({totalCount})
            </button>
            <button
              onClick={() => setFilter('in_progress')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                filter === 'in_progress'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              In Progress ({inProgressCount})
            </button>
            <button
              onClick={() => setFilter('solved')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all shrink-0 ${
                filter === 'solved'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Solved ({solvedCount})
            </button>
          </div>

          {/* Search Input */}
          <div className="relative sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by ID, area, or pincode..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Complaints List / Table */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center space-y-3">
          <FileText className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">No Complaints Match Your Search</h3>
          <p className="text-xs text-slate-500">
            Try clearing the search text or changing the status filter tab.
          </p>
          <button
            onClick={() => {
              setFilter('all');
              setSearchQuery('');
            }}
            className="px-4 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100"
          >
            Show All Complaints
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3.5">
          {filtered.map((item) => {
            const isSolved = item.status === 'solved';

            return (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs hover:border-blue-300 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
              >
                {/* Left side info */}
                <div className="flex items-start gap-4">
                  {/* Photo thumbnail */}
                  <div className="w-16 h-16 rounded-xl overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                    <img
                      src={item.photos[0] || 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=200&q=80'}
                      alt="Thumbnail"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">
                        #{item.id}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-medium text-xs">
                        {item.category}
                      </span>

                      {/* Status indicator badge (No orange, no green!) */}
                      {isSolved ? (
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                          <span>Solved</span>
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-100 text-sky-800 border border-sky-300 flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-sky-700" />
                          <span>In Progress ({item.status})</span>
                        </span>
                      )}
                    </div>

                    <h3 className="font-bold text-slate-800 text-sm">
                      {item.title}
                    </h3>

                    <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 pt-0.5">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {item.location.address}
                      </span>
                      <span className="font-semibold text-blue-700">
                        PIN: {item.location.pincode}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {item.createdAt}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right side action buttons */}
                <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                  <button
                    type="button"
                    onClick={() => setViewComplaint(item)}
                    className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5 text-slate-500" />
                    <span>View Details</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onTrackComplaint(item.id)}
                    className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs flex items-center gap-1.5"
                  >
                    <span>Track Live</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Details Modal */}
      {viewComplaint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden max-h-[90vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900">
                  Complaint #{viewComplaint.id}
                </span>
                {viewComplaint.status === 'solved' ? (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-800 border border-blue-300">
                    Solved
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-100 text-sky-800 border border-sky-300">
                    In Progress
                  </span>
                )}
              </div>
              <button
                onClick={() => setViewComplaint(null)}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto space-y-5 text-sm">
              <div>
                <span className="text-xs font-bold uppercase text-slate-400">
                  {viewComplaint.category}
                </span>
                <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                  {viewComplaint.title}
                </h2>
                <p className="text-slate-600 mt-2 text-xs sm:text-sm">
                  {viewComplaint.description}
                </p>
              </div>

              {/* Location Box */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1 text-xs">
                <div className="font-bold text-slate-700 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>Location & Pincode</span>
                </div>
                <div className="text-slate-800">{viewComplaint.location.address}</div>
                <div className="font-semibold text-blue-700">
                  Area Pincode: {viewComplaint.location.pincode}
                </div>
                {viewComplaint.location.landmark && (
                  <div className="text-slate-500">
                    Landmark: {viewComplaint.location.landmark}
                  </div>
                )}
              </div>

              {/* Photos Grid */}
              {viewComplaint.photos.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-700 mb-2">
                    Photos Uploaded ({viewComplaint.photos.length}):
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {viewComplaint.photos.map((p, idx) => (
                      <div
                        key={idx}
                        className="rounded-xl overflow-hidden border border-slate-200 aspect-video bg-slate-100"
                      >
                        <img src={p} alt="Photo" className="w-full h-full object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Latest Status Timeline */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 mb-2">
                  Status History ({viewComplaint.updates.length} updates):
                </h4>
                <div className="space-y-2">
                  {viewComplaint.updates.map((upd) => (
                    <div
                      key={upd.id}
                      className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-xs space-y-1"
                    >
                      <div className="flex justify-between font-bold text-slate-800">
                        <span>{upd.title}</span>
                        <span className="text-[11px] text-slate-500 font-normal">
                          {upd.date}
                        </span>
                      </div>
                      <div className="text-slate-600">{upd.note}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
              <button
                onClick={() => setViewComplaint(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg"
              >
                Close
              </button>

              <button
                onClick={() => {
                  const id = viewComplaint.id;
                  setViewComplaint(null);
                  onTrackComplaint(id);
                }}
                className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-xs flex items-center gap-1.5"
              >
                <span>Track on Progress Screen</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
