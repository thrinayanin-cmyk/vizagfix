import { Complaint, UserProfile, ComplaintStatus } from '../types';

const STORAGE_KEY_USER = 'vizagfix_user';
const STORAGE_KEY_COMPLAINTS = 'vizagfix_complaints';

export const DEFAULT_USER: UserProfile = {
  id: 'usr-9281',
  name: 'Harsha Kumar',
  email: 'nharshak0@gmail.com',
  phone: '+91 98480 22334',
  address: 'Plot 42, Beach Road, MVP Colony',
  pincode: '530017',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=250&q=80',
  joinedDate: 'January 2024',
  isGoogleUser: true,
};

export const INITIAL_COMPLAINTS: Complaint[] = [
  {
    id: 'CMP-1042',
    title: 'Street light not working near House #14',
    category: 'Street Lights',
    description: 'The street light has been completely dark for 4 days. It is very difficult for elderly people and children to walk at night.',
    urgency: 'Normal',
    location: {
      lat: 17.7294,
      lng: 83.3155,
      address: 'Main Cross Road, Sector 3, MVP Colony',
      pincode: '530017',
      landmark: 'Opposite Community Hall',
    },
    photos: [
      'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=600&q=80',
    ],
    status: 'in_progress',
    createdAt: '2026-11-02 09:30 AM',
    updatedAt: '2026-11-04 02:15 PM',
    estimatedDays: 3,
    assignedOfficer: {
      name: 'R. K. Sharma',
      department: 'Electrical Maintenance Dept',
      phone: '+91 94401 55667',
    },
    updates: [
      {
        id: 'upd-1',
        date: '2026-11-02 09:30 AM',
        title: 'Complaint Received',
        note: 'Your complaint was successfully registered in the system.',
        status: 'received',
      },
      {
        id: 'upd-2',
        date: '2026-11-03 11:00 AM',
        title: 'Checking Issue',
        note: 'Junior Electrical Engineer verified the post. Replacement bulb & wiring requested.',
        officerName: 'R. K. Sharma',
        department: 'Electrical Maintenance Dept',
        status: 'checking',
      },
      {
        id: 'upd-3',
        date: '2026-11-04 02:15 PM',
        title: 'Work in Progress',
        note: 'Repair van scheduled for installation of LED lighting fixture.',
        officerName: 'R. K. Sharma',
        status: 'in_progress',
      },
    ],
  },
  {
    id: 'CMP-1038',
    title: 'Deep pothole on Sector 4 entry road',
    category: 'Pothole & Roads',
    description: 'Dangerous pothole opened up after water leakage. Two two-wheelers already slipped yesterday.',
    urgency: 'Urgent',
    location: {
      lat: 17.7341,
      lng: 83.3218,
      address: 'Road No. 6, Near SBI ATM, Sector 4',
      pincode: '530017',
      landmark: 'Near SBI ATM Junction',
    },
    photos: [
      'https://images.unsplash.com/photo-1515162816999-a0c47dc192f7?auto=format&fit=crop&w=600&q=80',
    ],
    status: 'checking',
    createdAt: '2026-11-03 04:15 PM',
    updatedAt: '2026-11-04 10:00 AM',
    estimatedDays: 2,
    assignedOfficer: {
      name: 'K. Vijay Prasad',
      department: 'Roads & Works Wing',
      phone: '+91 94402 88991',
    },
    updates: [
      {
        id: 'upd-11',
        date: '2026-11-03 04:15 PM',
        title: 'Complaint Received',
        note: 'Urgent road safety complaint logged.',
        status: 'received',
      },
      {
        id: 'upd-12',
        date: '2026-11-04 10:00 AM',
        title: 'Checking Issue',
        note: 'Road inspector visited the location and marked safety barricades.',
        officerName: 'K. Vijay Prasad',
        department: 'Roads & Works Wing',
        status: 'checking',
      },
    ],
  },
  {
    id: 'CMP-1025',
    title: 'Garbage bin overflowing for two days',
    category: 'Garbage Cleanliness',
    description: 'Community waste container was completely full and spilling over. Needs immediate clearance.',
    urgency: 'Normal',
    location: {
      lat: 17.7265,
      lng: 83.3102,
      address: 'Lane 2, Sector 1, MVP Colony',
      pincode: '530017',
      landmark: 'Next to Children Park',
    },
    photos: [
      'https://images.unsplash.com/photo-1605600659908-0ef719419d41?auto=format&fit=crop&w=600&q=80',
    ],
    status: 'solved',
    createdAt: '2026-10-28 08:00 AM',
    updatedAt: '2026-10-29 05:30 PM',
    estimatedDays: 1,
    assignedOfficer: {
      name: 'M. Sridhar',
      department: 'Sanitation & Health Dept',
      phone: '+91 94403 11223',
    },
    updates: [
      {
        id: 'upd-21',
        date: '2026-10-28 08:00 AM',
        title: 'Complaint Received',
        note: 'Cleanliness request submitted.',
        status: 'received',
      },
      {
        id: 'upd-22',
        date: '2026-10-28 11:30 AM',
        title: 'Checking Issue',
        note: 'Sanitation supervisor assigned trash collection compactor truck.',
        officerName: 'M. Sridhar',
        status: 'checking',
      },
      {
        id: 'upd-23',
        date: '2026-10-29 02:00 PM',
        title: 'Work in Progress',
        note: 'Waste cleared and disinfectant powder sprayed around bin area.',
        officerName: 'M. Sridhar',
        status: 'in_progress',
      },
      {
        id: 'upd-24',
        date: '2026-10-29 05:30 PM',
        title: 'Solved & Verified',
        note: 'Task completed. Bin emptied, washed, and verified by sanitary inspector.',
        officerName: 'M. Sridhar',
        status: 'solved',
      },
    ],
  },
];

export function getUser(): UserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_USER) || localStorage.getItem('citizencare_user');
    if (!raw) {
      // Default to logged-in user so beginner immediately experiences the full system
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(DEFAULT_USER));
      return DEFAULT_USER;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_USER;
  }
}

export function saveUser(user: UserProfile | null): void {
  try {
    if (user) {
      localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEY_USER);
    }
  } catch (err) {
    console.error('Failed to save user', err);
  }
}

export function getComplaints(): Complaint[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_COMPLAINTS) || localStorage.getItem('citizencare_complaints');
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_COMPLAINTS, JSON.stringify(INITIAL_COMPLAINTS));
      return INITIAL_COMPLAINTS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_COMPLAINTS;
  } catch {
    return INITIAL_COMPLAINTS;
  }
}

export function saveComplaints(complaints: Complaint[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_COMPLAINTS, JSON.stringify(complaints));
  } catch (err) {
    console.error('Failed to save complaints', err);
  }
}

export function addComplaint(complaint: Complaint): void {
  const current = getComplaints();
  const updated = [complaint, ...current];
  saveComplaints(updated);
}

export function updateComplaintStatus(
  id: string,
  newStatus: ComplaintStatus,
  note: string = 'Status updated by citizen request'
): Complaint[] {
  const complaints = getComplaints();
  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  const titles: Record<ComplaintStatus, string> = {
    received: 'Complaint Received',
    checking: 'Checking Issue',
    in_progress: 'Work in Progress',
    solved: 'Solved & Verified',
  };

  const updated = complaints.map((c) => {
    if (c.id === id) {
      const newUpdate = {
        id: 'upd-' + Date.now(),
        date: dateStr,
        title: titles[newStatus],
        note: note,
        status: newStatus,
      };
      return {
        ...c,
        status: newStatus,
        updatedAt: dateStr,
        updates: [...c.updates, newUpdate],
      };
    }
    return c;
  });

  saveComplaints(updated);
  return updated;
}
