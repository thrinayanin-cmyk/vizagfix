import React, { useState, useEffect } from 'react';
import { UserProfile, Complaint, ComplaintStatus } from './types';
import {
  getUser,
  saveUser,
  getComplaints,
  saveComplaints,
  addComplaint as persistAddComplaint,
  updateComplaintStatus as persistUpdateStatus,
} from './services/storage';
import { Navbar } from './components/Navbar';
import { Dashboard } from './components/Dashboard';
import { FileComplaint } from './components/FileComplaint';
import { IssueProgress } from './components/IssueProgress';
import { ComplaintHistory } from './components/ComplaintHistory';
import { UserProfileView } from './components/UserProfileView';
import { AuthView } from './components/AuthView';
import { ShieldCheck } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => getUser());
  const [complaints, setComplaints] = useState<Complaint[]>(() => getComplaints());
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [selectedComplaintId, setSelectedComplaintId] = useState<string | undefined>(undefined);

  // Sync state changes with storage
  const handleLoginSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    saveUser(user);
    setCurrentTab('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    saveUser(null);
  };

  const handleUpdateUser = (updated: UserProfile) => {
    setCurrentUser(updated);
    saveUser(updated);
  };

  const handleAddComplaint = (newComplaint: Complaint) => {
    persistAddComplaint(newComplaint);
    setComplaints(getComplaints());
  };

  const handleUpdateStatus = (id: string, status: ComplaintStatus, note?: string) => {
    const updated = persistUpdateStatus(id, status, note);
    setComplaints(updated);
  };

  const handleNavigate = (tab: string, complaintId?: string) => {
    if (complaintId) {
      setSelectedComplaintId(complaintId);
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const activeComplaintsCount = complaints.filter((c) => c.status !== 'solved').length;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Banner Notice: Clean and Beginner-friendly */}
      <div className="bg-slate-900 text-white text-[11px] py-1.5 px-4 text-center font-medium border-b border-slate-800 flex items-center justify-center gap-2">
        <ShieldCheck className="w-3.5 h-3.5 text-blue-400" />
        <span>
          VizagFix Public Service Portal &bull; Easy Municipal Problem Reporting &amp; Live Tracking
        </span>
      </div>

      {/* Main Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(tab) => handleNavigate(tab)}
        currentUser={currentUser}
        onLogout={handleLogout}
        activeComplaintsCount={activeComplaintsCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {!currentUser ? (
          <AuthView onLoginSuccess={handleLoginSuccess} />
        ) : (
          <>
            {currentTab === 'dashboard' && (
              <Dashboard
                currentUser={currentUser}
                complaints={complaints}
                onNavigate={handleNavigate}
              />
            )}

            {currentTab === 'file_complaint' && (
              <FileComplaint
                currentUser={currentUser}
                onSubmitSuccess={handleAddComplaint}
                onTrackComplaint={(id) => handleNavigate('track_progress', id)}
              />
            )}

            {currentTab === 'track_progress' && (
              <IssueProgress
                complaints={complaints}
                selectedComplaintId={selectedComplaintId}
                onSelectComplaint={(id) => setSelectedComplaintId(id)}
                onUpdateStatus={handleUpdateStatus}
                onFileNewComplaint={() => handleNavigate('file_complaint')}
              />
            )}

            {currentTab === 'history' && (
              <ComplaintHistory
                complaints={complaints}
                onTrackComplaint={(id) => handleNavigate('track_progress', id)}
                onFileNewComplaint={() => handleNavigate('file_complaint')}
              />
            )}

            {currentTab === 'profile' && (
              <UserProfileView
                user={currentUser}
                complaints={complaints}
                onUpdateUser={handleUpdateUser}
                onFileComplaintClick={() => handleNavigate('file_complaint')}
              />
            )}

            {currentTab === 'auth' && (
              <AuthView onLoginSuccess={handleLoginSuccess} />
            )}
          </>
        )}
      </main>

      {/* Beginner-friendly Simple Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-8 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-800">VizagFix</span>
            <span>&bull; Public Grievance Portal</span>
          </div>

          <div className="flex items-center gap-6">
            <button
              onClick={() => handleNavigate('dashboard')}
              className="hover:text-blue-600 transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => handleNavigate('file_complaint')}
              className="hover:text-blue-600 transition-colors"
            >
              File a Complaint
            </button>
            <button
              onClick={() => handleNavigate('track_progress')}
              className="hover:text-blue-600 transition-colors"
            >
              Track Progress
            </button>
            <button
              onClick={() => handleNavigate('history')}
              className="hover:text-blue-600 transition-colors"
            >
              Complaint History
            </button>
            <button
              onClick={() => handleNavigate('profile')}
              className="hover:text-blue-600 transition-colors"
            >
              My Profile
            </button>
          </div>

          <div>
            <span>Municipal Helpline: 1800-425-0005 (Toll Free)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
